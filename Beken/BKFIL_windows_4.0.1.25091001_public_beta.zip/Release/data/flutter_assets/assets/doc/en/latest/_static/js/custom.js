var preUrl = ""
var hostRoot = ""
var asyncDone = false;
var sdkList = [
    {
        "name" : "app",
        "lang" : [ "zh-cn" ],
        "version" : [
            "latest"
        ]
    }
]

jQuery(function()
{
    var origin = window.location.origin;

    if (origin.indexOf("file://") == -1)
    {
        SdkVersionStartup();
    }
    else
    {
        autoFillVersionInfoForLocalShow();
        buildMultiVersionSelector();
        setPageStyle();
    }
    setFeedBackItem();
});


function SdkVersionStartup()
{
    var url = "/arminodoc/bk_app/version.json";
    var request = new XMLHttpRequest();

    request.open("get", url);
    request.send(null);
    request.onload = function () {

        if (request.status == 200) {
            var json = JSON.parse(request.responseText);
            sdkList = json;
        } else {
            autoFillVersionInfoForLocalShow();
        }

        buildMultiVersionSelector();
        setPageStyle();
    }

}


function autoFillVersionInfoForLocalShow()
{
    // auto change version to current version
    var urlList = window.location.pathname.split('/');

    if (urlList.length <= 3)
    {
        console.log("url error: " + curUrl);
        return;
    }

    let version = null;

    for (let index = 0; index < urlList.length; index++)
    {
        if (urlList[index] == "zh_CN" || urlList[index] == "en")
        {
            version = urlList[index + 1];
            break;
        }
    }

    if (version !== null) {
        for(let i = 0; i < sdkList.length; i++) {
            sdkList[i].version = [version]
        }
    }

}


function buildMultiVersionSelector()
{
    var curUrl = window.location.pathname;

    console.log("Current URL: " + curUrl)

    var urlList = curUrl.split('/');

    if (urlList.length <= 3)
    {
        console.log("url error: " + curUrl);
        return;
    }

    var target = urlList[1];
    var language = urlList[2] || "zh-cn";
    var version = urlList[3];
    var index;

    for (index = 0; index < urlList.length; index++)
    {
        if (urlList[index] == "zh_CN" || urlList[index] == "en")
        {
            language = urlList[index];
            target = urlList[index - 1];
            version = urlList[index + 1];
            break;
        }
    }

    if (urlList.length > 3)
    {
        preUrl = ""

        for (var i = 1; i < index - 1; i++)
        {
            preUrl += urlList[i] + "/"
        }
    }


    hostRoot = "/" + preUrl + target + "/" + language + "/" + version

    console.log("Index: " + index + " Name: " + target + " Language: " + language + " Version: " + version)

    console.log("Url: " + hostRoot)

    var searchUrl = $("#rtd-search-form").attr('action');

    // 移除target和version选择器，只保留搜索表单
    var versionPage = `
        <div role="search">
            <form id="rtd-search-form" class="wy-form" action="search.html" method="get" style="margin-top: 15px;">
                <input type="text" name="q" placeholder="Search docs" style="border-radius: 5px; border-color: #CCC; height: 35px; width: 100%;">
                <input type="hidden" name="check_keywords" value="yes">
                <input type="hidden" name="area" value="default">
            </form>
        </div>
        `;


    $("[role=search]").html(versionPage);
    $("#rtd-search-form").attr('action', searchUrl);

    // 保留基本的target和version变量定义以确保其他功能正常工作

    // 移除版本切换逻辑
    // 保留基本的target和version变量定义以确保其他功能正常工作
}

function setPageStyle()
{
    console.log($(".wy-breadcrumbs-aside").html())

    var stylePage = `
        <img id="styleIcon" src="_static/light.png" style="width: 24px; height: 24px; display: inline; align-items: center; cursor: pointer; margin-left:5px"></img>
        <img id="modeIcon" src="_static/open.png" style="width: 24px; height: 24px; display: inline; align-items: center; cursor: pointer; margin-left:5px"></img>
    `;
    $(".wy-breadcrumbs-aside").append(stylePage);

    var mode = localStorage.getItem('mode') || "light";
    setPageMode(mode);

    $("#styleIcon").bind('click', function()
    {
       var mode = $("#styleIcon").attr('mode'); 

       if(mode == "light")
       {
           mode = "dark";
       }
       else
       {
           mode = "light";
       }

       setPageMode(mode);

    });

    var styleSet = localStorage.getItem('styleSet') || "false";

    setPageWidth(styleSet);

    $("#modeIcon").bind('click', function()
    {

       var styleSet = $("#modeIcon").attr('styleSet');

       if(styleSet == "false")
       {
           styleSet = "true";
       }
       else
       {
           styleSet = "false";
       }
       setPageWidth(styleSet);
    });
}


function setPageMode(mode)
{
    if(mode == "light")
    {
        $("<link>").attr({ rel: "stylesheet", type: "text/css", href: hostRoot + "/_static/css/light.css" }).appendTo("head");
        $("#styleIcon").attr('src', hostRoot + '/_static/dark.png')
        $("#styleIcon").attr('mode', 'light');
        localStorage.setItem('mode', 'light');
    }
    else
    {
        $("<link>").attr({ rel: "stylesheet", type: "text/css", href: hostRoot + "/_static/css/dark.css" }).appendTo("head");
        $("#styleIcon").attr('src', hostRoot + '/_static/light.png')
        $("#styleIcon").attr('mode', 'dark');
        localStorage.setItem('mode', 'dark');
    }
}


function setPageWidth(styleSet)
{
    if(styleSet == "false")
    {
        $("#modeIcon").attr('src', hostRoot + '/_static/open.png')
        $("#modeIcon").attr('styleSet', 'false');
        $(".wy-nav-content").attr('style', 'max-width:888px');
        localStorage.setItem('styleSet', 'false');
    }
    else
    {
        $("#modeIcon").attr('src', hostRoot + '/_static/close.png')
        $("#modeIcon").attr('styleSet', 'true');
        $(".wy-nav-content").attr('style', 'max-width:none');
        localStorage.setItem('styleSet', 'true');
    }
}

function setFeedBackItem()
{
    if ($("#doc-feedback").length > 0) {
        const versionNum = encodeURIComponent($("#version-id").val());
        let title = encodeURIComponent($(document).attr('title'));
        let itemDesc = 'provide feedback about this doc';
        if (window.location.pathname.includes('zh_CN')) {
            itemDesc = '反馈该文档建议';
        }
        $("#doc-feedback").append('<a target="_blank" href="https://docs.bekencorp.com/docfeedback?title=' + title + '&versionNum=' + versionNum + '">' + itemDesc +'</a>');
    }
}