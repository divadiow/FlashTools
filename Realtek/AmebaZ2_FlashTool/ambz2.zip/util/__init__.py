#  Copyright (c) Kuba Szczodrzyński 2022-12-21.
