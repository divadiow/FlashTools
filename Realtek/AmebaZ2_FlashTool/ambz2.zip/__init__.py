#  Copyright (c) Kuba Szczodrzyński 2022-12-28.

from .main import AmebaZ2Main

__all__ = [
    "AmebaZ2Main",
]
