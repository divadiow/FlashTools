If the update fails, please click https://d.oo14.com/a6Lw to download manually! ! !
If the update fails, please click https://d.oo14.com/a6Lw to download manually! ! !
If the update fails, please click https://d.oo14.com/a6Lw to download manually! ! !

2019.9.6 ThingsTurn_Serial_Tool V1.5.3.0
******************************************
1. Added file sending function;
2. Added multiple product selections, double-click to view IO distribution;
3. Added multi-text button annotation function, F2 rename, Enter confirm, ESC cancel, remember to click Save below after modification;
4. Optimized the interface display layout so that the download button can be displayed in split screen at the same time;
5. Optimized the processing when burning a separate gain file, select BLANK to read only MAC and GAIN values;
6. Optimized the crash problem when the serial port receives a large amount of data, basically no crash, tested my computer blue screen several times but still no crash.

2019.8.10 ThingsTurn_Serial_Tool V1.5.2.0
******************************************
1. Added download tool packaging function, supports custom title and Gain value, and the firmware size is limited to 1M.
2. Optimize the executable file size and separate the pin image to facilitate subsequent updates of other models.
3. Fix the update server problem. If the automatic update fails, please try to update manually.

2019.7.29 ThingsTurn_Serial_Tool V1.5.1.1
******************************************
1. Fix the problem of restarting the configuration reading error after selecting the background color.

2019.7.28 ThingsTurn_Serial_Tool V1.5.1.0
******************************************
1. Added the option to force the serial port to open after downloading;
2. Added background color settings and received text font settings;
3. Added support for CTRL+mouse wheel to directly adjust the font size;
4. Added the function that when an error occurs in reading the configuration information, the original configuration file will be transferred and the default settings will be restored and restarted;
5. Added support for custom modification of whether to display product information and online resources (serial_tool.cfg needs to be modified by yourself);
6. Added support for custom modification of window titles and information (serial_tool.cfg needs to be modified by yourself);
7. Updated the document URL corresponding to the built-in product, from https://docs.thingsturn.com to https://docs.w600.fun;
8. In response to the requirements of some obsessive-compulsive users, the pop-up window will no longer appear when the serial port connection is interrupted, and it will only pop up to the front of the window;
9. Added Gain value files corresponding to W600, TB-02, TW-602, etc. The W600 model can be used before the Gain value of the new module or new development board is confirmed.

2019.6.28 ThingsTurn_Serial_Tool V1.5.0.2
******************************************
1. Added file recognition function to support separate download of secboot files and RT-Thread's rbl upgrade files;
2. Modified the failure to download a separate gain file;
3. Modified that when the serial port is not opened before downloading, the serial port will no longer be forced to open after the download is completed;
4. Optimized the problem of opening the serial port, the operation is too fierce, resulting in continuous clicks on the serial port and then being closed;
5. Optimized the problem of stopping operation when a large amount of data is transmitted;
6. Optimized the product selection picture, highlighting the double-click operation to view IO details;
7. Optimized the size of the executable file.

2019.5.8 ThingsTurn_Serial_Tool V1.5.0.1
******************************************
1. Fixed the problem that when the serial port receives discontinuous P and C, it mistakenly thinks that it has entered the download mode and does not actively reset, resulting in download failure;
2. Fixed the drop-down list display delay problem;
3. Fixed the width display of the script drop-down list;
4. Remove the minimum size limit when minimizing the window;
5. Enable some controls to be available when the serial port is not open.

2019.4.16 ThingsTurn_Serial_Tool V1.5.0
******************************************
1. Added download history function, single-click to select, double-click to download directly;
2. Added support for multi-text cyclic sending;
3. Added product selection page, double-click to view detailed IO definition and function reuse;
4. Added online resource display, you can quickly find the required information;
5. Added automatic download of gain value information according to the selected module model, and select Unknown for unknown models. Gain values ​​will not be written repeatedly when they are the same;
6. Fixed the issue that the file will not be saved when there is no record in the sending history on the same day;
7. Support checking whether the module is in download mode before downloading. If yes, the module will not be reset and the handshake will be performed directly to save download time;
8. When a suspected old version of secboot is detected, the fls file will be downloaded directly using the baud rate of 115200;
9. Fixed the problem that CP2102N cannot be opened (unverified);
10. Added description information when the serial port list is pulled down;
11. Added automatic device reset after download (serial port hardware connection support is required);
12. Added automatic conversion of \n to \r\n when receiving data;
13. Added adaptive size of the startup window according to resolution and ratio;

2019.1.19 ThingsTurn_Serial_Tool V1.4.5
******************************************
1. Fixed the problem that the old version of SECBOOT cannot read MAC and erase SECBOOT, resulting in firmware download failure,
2. Support downloading Gain value

2019.1.8 ThingsTurn_Serial_Tool V1.4.2
******************************************
1. Optimize the way to enter SECBOOT mode
2. Update LOGO

2018.12.31 ThingsTurn_Serial_Tool V1.4.1
******************************************
1. Remove the erase button;
2. Remove the quick download button;
3. Add the function of reading MAC before downloading;
4. Add the option of erasing SECBOOT or the entire FLASH before downloading;
5. Add the function of continuous downloading;
6. Add the function of judging the format of the downloaded file, which will prompt the correct file format;
7. Add the function of printing the file name and file path judgment before downloading.

2018.12.29 ThingsTurn_Serial_Tool V1.3.8
******************************************
1 Fixed the problem that SDK 3.1 cannot be downloaded and erased
2 Fixed the problem of timestamp display error
3 Added a button for quick download of fls
4 Added a compatible version of the instruction set script

2018.10.18 ThingsTurn_Serial_Tool V1.3.6
******************************************
1 Fixed the erase Flash function (only supports sdk v2.2.8 and above)

2018.10.14 ThingsTurn_Serial_Tool V1.3.5
******************************************
1 Added the erase Flash function
2 Added the automatic update function

****************************

2018.10.3 ThingsTurn_Serial_Tool V1.3.4
**********************************************
1 Supports download speed up to 2Mbps
If you used an old version of SDK before, you need to download WM_W600_NEW_BOOT.FLS in the same directory to update secboot
2 Supports adding new scripts. When no script is selected, multiple text boxes are prohibited
3 Optimize w600 download process

****************************

Shenzhen Xingtong Zhilian Technology Co., Ltd.
Website: www.thingsturn.com
E-mail: support@thingsturn.com